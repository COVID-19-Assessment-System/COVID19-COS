from datetime import datetime, timedelta
from dateutil.parser import parse
import random
import pandas as pd
import numpy as np
import sklearn
from sklearn import cluster
from sklearn.metrics import silhouette_score
from sklearn import preprocessing
import matplotlib.pyplot as plt
from matplotlib import cm

class SlClusteringPeople:
    df_corona = None
    added_column_list = []
    cluster_result_dic = {}

    sse_list = []
    centroids_coord_list = []

    num_healthy = 0
    healthy_id_list = []
    num_contacted = 0
    contacted_id_list = []
    num_confirmed = 0
    confirmed_id_list = []

    def __init__(self, file_path):
        self.load_data(file_path)
        self.compute_severity()
        self.compute_people_number_of_type()

    def load_data(self, file_path):
        """
        method to load .csv file
        :param file_path: string, the path of file
        :return:
        """
        self.df_corona = pd.read_csv(file_path)

    def compute_people_number_of_type(self):
        status_series = self.df_corona["Covid Status"]
        for idx in range(len(status_series)):
            if status_series[idx] == 'Contacted':
                self.num_contacted += 1
                self.contacted_id_list.append(idx+1)
            elif status_series[idx] == 'Confirmed':
                self.num_confirmed += 1
                self.confirmed_id_list.append(idx+1)
            else:
                self.num_healthy += 1
                self.healthy_id_list.append(idx+1)

    def compute_average_severity(self, id_list):
        sum_of_severity = 0
        for id in id_list:
            sum_of_severity += self.df_corona["Severity"][id-1]
        return sum_of_severity / len(id_list)


    def display_load_data(self):
        print(f"Total number of People: {len(self.df_corona)}")
        print(f"{'ID':<4}"
              f"{'Age':<4}"
              f"{'Covid Status':<13}"
              f"{'Severity':<9}"
              f"{'Address':<10}")
        for i in range(len(self.df_corona)):
            print(f"{self.df_corona['ID'][i]:<4}"
                  f"{self.df_corona['Age'][i]:<4}"
                  f"{self.df_corona['Covid Status'][i]:<13}"
                  f"{round(self.df_corona['Severity'][i], 3):<9}"
                  f"{self.df_corona['Address'][i].split()[0]:<10}"
                  )
        print()  # float 1 line
        print(f"Number of healthy people: {self.num_healthy}")
        print(f"Number of contacted people: {self.num_contacted}")
        print(f"Number of confirmed people: {self.num_confirmed}")
        print(f"Average Severity of contacted people: "
              f"{round(self.compute_average_severity(self.contacted_id_list), 2)}")
        print(f"Average Severity of confirmed people: "
              f"{round(self.compute_average_severity(self.confirmed_id_list), 2)}")
        print()  # float 1 line

    def compute_severity(self):
        """
        method to preprocess the data for distance function
        :return: None
        """
        col_num = len(self.df_corona)  # the number of rows from loaded data
        today = datetime.now().date()  # date of today, YEAR-MONTH-DAY

        # selecting specific column to compute 'severity'
        incur_date_col = self.df_corona['Incurred Date']
        status = self.df_corona['Covid Status']

        severity_list = []  # list for storing severity result

        for i in range(col_num):
            severity = 0  # default is healthy, 0.
            if status[i] == 'Contacted':  # contacted person?
                # formula for contacted person:
                #   x = 1 - ((today's date) - (infected date)) * 0.05)
                elapsed_days = (today - parse(incur_date_col[i]).date()).days
                severity = (1 - (elapsed_days * 0.05)) * 0.5

            elif status[i] == 'Confirmed':  # confirmed person?
                # formula for confirmed person:
                #   x = (1 - ((today's date) - (infected date)) * 0.05)) / 2
                elapsed_days = (today - parse(incur_date_col[i]).date()).days
                severity = 1 - (elapsed_days * 0.05)

            severity_list.append(severity)  # add the value to the list
        self.df_corona["Severity"] = severity_list
        self.added_column_list.append("Severity")
        self.added_column_list.append("Age")

    def cluster_kmeans(self, col_name_list, num_cluster):
        # load the k-means model
        km = cluster.KMeans(
            n_clusters=num_cluster,  # the number of cluster
            init='k-means++',  # how to initial cluster centers
            max_iter=300,  # maximum number of iterations
            algorithm='auto'  # three choices: auto, full, and elkan.
        )

        # cluster
        if len(col_name_list) == 1:
            target_data = self.df_corona[col_name_list].values.tolist()
            target_data = np.array(target_data)
            cluster_predicted_list = km.fit_predict(
                target_data.reshape(-1, 1))  # changing the shape of data
            silhouette_score_list.append(
                silhouette_score(target_data.reshape(-1, 1),
                                 cluster_predicted_list))

        else:  # at least 2 column
            target_data = self.df_corona[col_name_list]

            min_max_scaler = preprocessing.MinMaxScaler()
            target_data = min_max_scaler.fit_transform(target_data)

            cluster_predicted_list = km.fit_predict(target_data)
            silhouette_score_list.append(
                silhouette_score(target_data,
                                 cluster_predicted_list))

        # storing the coordinates of centroids
        self.centroids_coord_list.append(km.cluster_centers_)

        # storing the prediction result
        self.cluster_result_dic[num_cluster] = cluster_predicted_list

        # storing SSE(Sum of Squared Errors)
        self.sse_list.append(km.inertia_)

        return cluster_predicted_list

    def draw_elbow_method(self, sse_list):
        """
        method to draw elbow graph using SSE(Sum of Squares Error)
        :param sse_list: list of SSE
        :return: None
        """
        plt.plot(range(2, 10), sse_list, marker='o')
        plt.xlabel("The Number of Cluster")
        plt.ylabel("SSE")
        plt.show()

    def print_result_of_cluster(self,
                                num_cluster,
                                cluster_idx_list,
                                cluster_predicted_list):

        severity_list = self.df_corona["Severity"].values.tolist()
        age_list = self.df_corona["Age"].values.tolist()

        cluster_predicted_list = cluster_predicted_list.tolist()
        people_num_of_a_cluster_list = []
        avg_age_of_a_cluster_list = []
        avg_severity_of_a_cluster_list = []

        print(f"Number of Clusters: {len(cluster_idx_list)}")

        for cluster_idx in cluster_idx_list:  # 1 cluster
            num_people = cluster_predicted_list.count(cluster_idx)
            id_target_data_tuple_list = []
            sum_of_severities = 0
            sum_of_ages = 0

            for person_idx in range(len(cluster_predicted_list)):
                if cluster_idx == cluster_predicted_list[person_idx]:
                    sum_of_severities += severity_list[person_idx]
                    sum_of_ages += age_list[person_idx]
                    id_target_data_tuple_list.append((
                        person_idx+1,  # [0] of tuple is id
                        age_list[person_idx],  # [1] of tuple is age
                        round(severity_list[person_idx], 2)))  # [2] of tuple is severity

            people_num_of_a_cluster_list.append(num_people)

            print(f"\tCluster {cluster_idx}:")
            print(f"\t\tNumber of People: {num_people}")
            # print(f"\t\t\t{'ID':<4}{'Age':<4}{'Severity Value'}")
            # for person_in_cluster in id_target_data_tuple_list:
            #     print(f"\t\t\t{person_in_cluster[0]:<4}"
            #           f"{person_in_cluster[1]:<4}"
            #           f"{person_in_cluster[2]}")

            print(f"\t\tAverage of Age: "
                  f"{round(sum_of_ages / len(id_target_data_tuple_list), 2)}")
            print(f"\t\tAverage of severities: "
                  f"{round(sum_of_severities / len(id_target_data_tuple_list), 2)}")
            print(f"\t\tThe Coordinates of Centroid:")
            coords = self.centroids_coord_list[num_cluster-2][cluster_idx]
            print(f"\t\t\tX1 (Severity): {round(coords[0], 2)}")
            print(f"\t\t\tX2 (Age): {round(coords[1], 2)}")

            avg_age_of_a_cluster_list.append(
                round(sum_of_ages / len(id_target_data_tuple_list), 2))
            avg_severity_of_a_cluster_list.append(
                round(sum_of_severities / len(id_target_data_tuple_list), 2))

            print()  # float 1 line
        self.display_summary_table(people_num_of_a_cluster_list,
                                   avg_age_of_a_cluster_list,
                                   avg_severity_of_a_cluster_list)
        print()  # float 1 line

    def data_to_csv(self, num_cluster, cluster_label_list):
        temp_df = self.df_corona.__deepcopy__()
        temp_df[f"Cluster ID: {num_cluster}"] = cluster_label_list

        # rounding the values
        # temp_series = self.df_corona['Severity']

        file_name = f"clustered_corona_data_k={num_cluster}_" \
                    f"{'_'.join(self.added_column_list)}.csv"
        temp_df.to_csv(file_name, encoding='utf-8-sig')

    def display_summary_table(self,
                              people_of_cluster_list,
                              avg_age_of_cluster_list,
                              avg_severity_of_cluster_list):
        len_id = 11
        len_p_num = 11
        len_age = 13
        len_sev = 15
        len_sum = len_id+len_p_num+len_age+len_sev

        # top row
        print(f"\t{'-'*(len_sum+11)}")
        print(f"\t{'Cluster ID':>{len_id}} "
              f"| {'# of People':>{len_p_num}} "
              f"| {'Avg. of Ages':>{len_age}} "
              f"| {'Avg. of Severity':>{len_sev}} ")

        # contents of table
        cluster_id = 0
        for people_num, avg_age, avg_sev in zip(people_of_cluster_list,
                                                avg_age_of_cluster_list,
                                                avg_severity_of_cluster_list):
            print(f"\t{cluster_id:>{len_id}} "
                  f"| {people_num:>{len_p_num}} "
                  f"| {avg_age:>{len_age}} "
                  f"|{avg_sev:>{len_sev}}")
            cluster_id += 1

        print(f"\t{'-'*(len_id+1)}"
              f"|{'-'*(len_p_num+2)}"
              f"|{'-'*(len_age+2)}"
              f"|{'-'*(len_sev+2)}-")

        # bottom row
        print(f"\t{'Total':^{len_id}} | {sum(people_of_cluster_list):>{len_p_num}} |")
        print(f"\t{'SSE':^{len_id}} | {round(self.sse_list[len(people_of_cluster_list)-2], 2):>{len_p_num}} |")
        print(f"\t{'-'*(len_sum+11)}")

    def draw_silhouette(self):
        """
        method to draw graph using silhouette scores
        :return: None
        """
        pass

    def draw_graph(self):
        """
        method to draw clustering result
        :return: None
        """
        pass


if __name__ == '__main__':
    # CODE FOR CLUSTERING
    file_path = './corona_data.csv'

    cp = SlClusteringPeople(file_path)
    cp.display_load_data()

    sse_list = []  # list for storing SSE(Sum of squares errors)
    silhouette_score_list = []  # list for storing silhouette scores

    # cluster with 'Severity' and 'Age' columns
    col_name_list = ['Severity', 'Age']
    k_list = [k for k in range(2, 10)]  # cluster list

    for num_cluster in k_list:
        cluster_id_list = [id for id in range(num_cluster)]
        predicted_list = cp.cluster_kmeans(col_name_list, num_cluster)
        cp.print_result_of_cluster(num_cluster,
                                   cluster_id_list,
                                   predicted_list)
        cp.data_to_csv(num_cluster, predicted_list)

